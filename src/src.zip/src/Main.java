public class Main {
    public static void main(String[] args) {
        Livre livre = new Livre (101, "Introduction a Java", "Auteur inconnu", 320);
        Periodique periodique = new Periodique (202, "Science et technique", "Auteur inconnu", 12);
        System.out.println(livre);
        System.out.println(periodique);
// Verification des durees maximales de pret
        System.out.println("Dureemaxpret livre:" + livre.dureeMaxPret() );
        System.out.println("Dureemaxpret periodique:" + periodique.dureeMaxPret());
// Disponibilite initiale
        System.out.println("Disponible avant emprunt: " + livre.isDisponible());
// Apres emprunt
        livre.emprunter();
        System.out.println("Disponible apres emprunter():" + livre.isDisponible() );
// Apres retourner()
        livre.retourner();
        System.out.println("Disponible apres retourner(): " + livre.isDisponible() );
    }
}