public abstract class Document {
    private int numero;
    private String titre;
    private String auteurPrincipal;
    private boolean disponible;
    public Document (int numero, String titre, String auteurPrincipal) {
        this.numero = numero;
        this.titre = titre;
        this.auteurPrincipal = auteurPrincipal;
        this.disponible = true; // disponible des la creation
    }
    public int getNumero() {
        return numero;
    }
    public String getTitre() {
        return titre;
    }
    public String getAuteurPrincipal() {
            return auteurPrincipal;
    }
    public boolean isDisponible() {
            return disponible;
    }
    public void emprunter() {
    }
    public void retourner() {
            disponible = true;
    }
    public abstract int dureeMaxPret();
        @Override
        public String toString() {
            return "numero=" + numero + " titre=" + titre + " auteurPrincipal=" + auteurPrincipal + "disponible=" + disponible;
        }
    }
